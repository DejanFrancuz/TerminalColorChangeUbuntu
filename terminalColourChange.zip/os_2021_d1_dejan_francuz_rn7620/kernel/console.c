// Console input and output.
// Input is from the keyboard or serial port.
// Output is written to the screen and serial port.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "traps.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "kbd.h"


static void consputc(int);

static short fg=0x0700;
static short bg=0x0000;

static uint colors[15];
static int panicked = 0;

static struct {
	struct spinlock lock;
	int locking;
} cons;

static void
printint(int xx, int base, int sign)
{
	static char digits[] = "0123456789abcdef";
	char buf[16];
	int i;
	uint x;

	if(sign && (sign = xx < 0))
		x = -xx;
	else
		x = xx;

	i = 0;
	do{
		buf[i++] = digits[x % base];
	}while((x /= base) != 0);

	if(sign)
		buf[i++] = '-';

	while(--i >= 0)
		consputc(buf[i]);
}

// Print to the console. only understands %d, %x, %p, %s.
void
cprintf(char *fmt, ...)
{
	int i, c, locking;
	uint *argp;
	char *s;

	locking = cons.locking;
	if(locking)
		acquire(&cons.lock);

	if (fmt == 0)
		panic("null fmt");

	argp = (uint*)(void*)(&fmt + 1);
	for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
		if(c != '%'){
			consputc(c);
			continue;
		}
		c = fmt[++i] & 0xff;
		if(c == 0)
			break;
		switch(c){
		case 'd':
			printint(*argp++, 10, 1);
			break;
		case 'x':
		case 'p':
			printint(*argp++, 16, 0);
			break;
		case 's':
			if((s = (char*)*argp++) == 0)
				s = "(null)";
			for(; *s; s++)
				consputc(*s);
			break;
		case '%':
			consputc('%');
			break;
		default:
			// Print unknown % sequence to draw attention.
			consputc('%');
			consputc(c);
			break;
		}
	}

	if(locking)
		release(&cons.lock);
}

void
panic(char *s)
{
	int i;
	uint pcs[10];

	cli();
	cons.locking = 0;
	// use lapiccpunum so that we can call panic from mycpu()
	cprintf("lapicid %d: panic: ", lapicid());
	cprintf(s);
	cprintf("\n");
	getcallerpcs(&s, pcs);
	for(i=0; i<10; i++)
		cprintf(" %p", pcs[i]);
	panicked = 1; // freeze other CPU
	for(;;)
		;
}

#define BACKSPACE 0x100
#define CRTPORT 0x3d4
static ushort *crt = (ushort*)P2V(0xb8000);  // CGA memory
static ushort help[2000];

static void
cgaputc(int c)
{
	int pos;
        //int (*getc)(void);

	// Cursor position: col + 80*row.
	outb(CRTPORT, 14);
	pos = inb(CRTPORT+1) << 8;
	outb(CRTPORT, 15);
	pos |= inb(CRTPORT+1);

	if(c == '\n'){
               crt[pos] = 32 | (fg^bg);
		pos += 80 - pos%80;

            }
	else if(c == BACKSPACE){
		if(pos > 0){ --pos;
                 crt[pos+1]= 32 | (fg^bg);
            }
	} else{
                crt[pos++] = (c&0xff) ^ (fg^bg) ;              
             }
	if(pos < 0 || pos > 25*80)
		panic("pos under/overflow");

	if((pos/80) >= 24){  // Scroll up.
		memmove(crt, crt+80, sizeof(crt[0])*23*80);
		pos -= 80;
		memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
	}

	outb(CRTPORT, 14);
	outb(CRTPORT+1, pos>>8);
	outb(CRTPORT, 15);
	outb(CRTPORT+1, pos);
	crt[pos] = ' ' ^ (fg^bg);
      
         }
void meni(){
        crt[57] = 47 | 0x0f00; // pocetak prvog reda
       crt[58] = 45 | 0x0f00;
       crt[59] = 45 | 0x0f00;       
       crt[60] = 45 | 0x0f00;
       crt[61] = 60 | 0x0f00;
       crt[62] = 70 | 0x0f00;
       crt[63] = 71 | 0x0f00;
       crt[64] = 62 | 0x0f00;
       crt[65] = 45 | 0x0f00;
       crt[66] = 45 | 0x0f00;
       crt[67] = 45 | 0x0f00;
       crt[68] = 32 | 0x0f00;
       crt[69] = 45 | 0x0f00;
       crt[70] = 45 | 0x0f00;
       crt[71] = 45 | 0x0f00;
       crt[72] = 60 | 0x0f00;
       crt[73] = 66 | 0x0f00;
       crt[74] = 71 | 0x0f00;
       crt[75] = 62 | 0x0f00;
       crt[76] = 45 | 0x0f00;
       crt[77] = 45 | 0x0f00;
       crt[78] = 45 | 0x0f00;
       crt[79] = 92 | 0x0f00; // kraj prvog reda
       crt[137] = 124 | 0x0f00; // pocetak prve kolone
       crt[217] = 124 | 0x0f00;
       crt[297] = 124 | 0x0f00;
       crt[377] = 124 | 0x0f00;
       crt[457] = 124 | 0x0f00;
       crt[537] = 124 | 0x0f00;
       crt[617] = 124 | 0x0f00;
       crt[697] = 124 | 0x0f00; // kraj prve kolone

       crt[148] = 124 | 0x0f00; // pocetak srednje kolone
       crt[228] = 124 | 0x0f00;
       crt[308] = 124 | 0x0f00;
       crt[388] = 124 | 0x0f00;
       crt[468] = 124 | 0x0f00;
       crt[548] = 124 | 0x0f00;
       crt[628] = 124 | 0x0f00;
       crt[708] = 124 | 0x0f00; // kraj srednje kolone


       crt[159] = 124 | 0x0f00; // pocetak poslednje kolone
       crt[239] = 124 | 0x0f00;
       crt[319] = 124 | 0x0f00;
       crt[399] = 124 | 0x0f00;
       crt[479] = 124 | 0x0f00;
       crt[559] = 124 | 0x0f00;
       crt[639] = 124 | 0x0f00;
       crt[719] = 124 | 0x0f00; // kraj poslednje kolone

       crt[777] = 92 | 0x0f00; // pocetak poslednjeg reda
       crt[778] = 45 | 0x0f00;
       crt[779] = 45 | 0x0f00;
       crt[780] = 45 | 0x0f00;
       crt[781] = 45 | 0x0f00;
       crt[782] = 45 | 0x0f00;
       crt[783] = 45 | 0x0f00;
       crt[784] = 45 | 0x0f00;
       crt[785] = 45 | 0x0f00;
       crt[786] = 45 | 0x0f00;
       crt[787] = 45 | 0x0f00;
       crt[788] = 45 | 0x0f00;
       crt[789] = 45 | 0x0f00;
       crt[790] = 45 | 0x0f00;
       crt[791] = 45 | 0x0f00;
       crt[792] = 45 | 0x0f00;
       crt[793] = 45 | 0x0f00;
       crt[794] = 45 | 0x0f00;
       crt[795] = 45 | 0x0f00;
       crt[796] = 45 | 0x0f00;
       crt[797] = 45 | 0x0f00;
       crt[798] = 45 | 0x0f00;
       crt[799] = 47 | 0x0f00; // kraj poslednjeg reda

       crt[138] = 66 | 0x0f00; // black
       crt[139] = 108 | 0x0f00;
       crt[140] = 97 | 0x0f00;
       crt[141] = 99 | 0x0f00;
       crt[142] = 107 | 0x0f00;
       crt[143] = 32 | 0x0f00; 
       crt[144] = 32 | 0x0f00;
       crt[145] = 32 | 0x0f00;
       crt[146] = 32 | 0x0f00;
       crt[147] = 32 | 0x0f00;

       crt[149] = 66 | 0x0f00;
       crt[150] = 108 | 0x0f00;
       crt[151] = 97 | 0x0f00;
       crt[152] = 99 | 0x0f00;
       crt[153] = 107 | 0x0f00;
       crt[154] = 32 | 0x0f00; 
       crt[155] = 32 | 0x0f00;
       crt[156] = 32 | 0x0f00;
       crt[157] = 32 | 0x0f00;
       crt[158] = 32 | 0x0f00;

       crt[218] = 66 | 0x0f00; // blue
       crt[219] = 108 | 0x0f00;
       crt[220] = 117 | 0x0f00;
       crt[221] = 101 | 0x0f00;
       crt[222] = 32 | 0x0f00; 
       crt[223] = 32 | 0x0f00;
       crt[224] = 32 | 0x0f00;
       crt[225] = 32 | 0x0f00;
       crt[226] = 32 | 0x0f00;
       crt[227] = 32 | 0x0f00;


       crt[229] = 66 | 0x0f00; 
       crt[230] = 108 | 0x0f00;
       crt[231] = 117 | 0x0f00;
       crt[232] = 101 | 0x0f00;
       crt[233] = 32 | 0x0f00; 
       crt[234] = 32 | 0x0f00;
       crt[235] = 32 | 0x0f00;
       crt[236] = 32 | 0x0f00;
       crt[237] = 32 | 0x0f00;
       crt[238] = 32 | 0x0f00;

       crt[298] = 71 | 0x0f00; // green
       crt[299] = 114 | 0x0f00;
       crt[300] = 101 | 0x0f00;
       crt[301] = 101 | 0x0f00;
       crt[302] = 110 | 0x0f00;
       crt[303] = 32 | 0x0f00;
       crt[304] = 32 | 0x0f00;
       crt[305] = 32 | 0x0f00;
       crt[306] = 32 | 0x0f00;
       crt[307] = 32 | 0x0f00;


       crt[309] = 71 | 0x0f00; 
       crt[310] = 114 | 0x0f00;
       crt[311] = 101 | 0x0f00;
       crt[312] = 101 | 0x0f00;
       crt[313] = 110 | 0x0f00;
       crt[314] = 32 | 0x0f00;
       crt[315] = 32 | 0x0f00;
       crt[316] = 32 | 0x0f00;
       crt[317] = 32 | 0x0f00;
       crt[318] = 32 | 0x0f00;

       crt[378] = 65 | 0x0f00; // aqua
       crt[379] = 113 | 0x0f00;       
       crt[380] = 117 | 0x0f00;
       crt[381] = 97 | 0x0f00;
       crt[382] = 32 | 0x0f00;
       crt[383] = 32 | 0x0f00;
       crt[384] = 32 | 0x0f00;
       crt[385] = 32 | 0x0f00;
       crt[386] = 32 | 0x0f00;       
       crt[387] = 32 | 0x0f00;


       crt[389] = 65 | 0x0f00;
       crt[390] = 113 | 0x0f00;
       crt[391] = 117 | 0x0f00;
       crt[392] = 97 | 0x0f00;
       crt[393] = 32 | 0x0f00;       
       crt[394] = 32 | 0x0f00;
       crt[395] = 32 | 0x0f00;
       crt[396] = 32 | 0x0f00;
       crt[397] = 32 | 0x0f00;
       crt[398] = 32 | 0x0f00;

       crt[458] = 82 | 0x0f00; // red
       crt[459] = 101 | 0x0f00;
       crt[460] = 100 | 0x0f00;
       crt[461] = 32 | 0x0f00;
       crt[462] = 32 | 0x0f00;
       crt[463] = 32 | 0x0f00;
       crt[464] = 32 | 0x0f00;
       crt[465] = 32 | 0x0f00;
       crt[466] = 32 | 0x0f00;
       crt[467] = 32 | 0x0f00;

       crt[469] = 82 | 0x0f00; 
       crt[470] = 101 | 0x0f00;
       crt[471] = 100 | 0x0f00;
       crt[472] = 32 | 0x0f00;
       crt[473] = 32 | 0x0f00;
       crt[474] = 32 | 0x0f00;
       crt[475] = 32 | 0x0f00;
       crt[476] = 32 | 0x0f00;
       crt[477] = 32 | 0x0f00;
       crt[478] = 32 | 0x0f00;

       crt[538] = 80 | 0x0f00; // purple
       crt[539] = 117 | 0x0f00;
       crt[540] = 114 | 0x0f00;
       crt[541] = 112 | 0x0f00;
       crt[542] = 108 | 0x0f00;
       crt[543] = 101 | 0x0f00;
       crt[544] = 32 | 0x0f00;
       crt[545] = 32 | 0x0f00;
       crt[546] = 32 | 0x0f00;       
       crt[547] = 32 | 0x0f00;


       crt[549] = 80 | 0x0f00; 
       crt[550] = 117 | 0x0f00;
       crt[551] = 114 | 0x0f00;
       crt[552] = 112 | 0x0f00;
       crt[553] = 108 | 0x0f00;
       crt[554] = 101 | 0x0f00;
       crt[555] = 32 | 0x0f00;
       crt[556] = 32 | 0x0f00;
       crt[557] = 32 | 0x0f00;
       crt[558] = 32 | 0x0f00;

       crt[618] = 89 | 0x0f00; // yellow
       crt[619] = 101 | 0x0f00;
       crt[620] = 108 | 0x0f00;
       crt[621] = 108 | 0x0f00;
       crt[622] = 111 | 0x0f00;
       crt[623] = 119 | 0x0f00;
       crt[624] = 32 | 0x0f00;
       crt[625] = 32 | 0x0f00;
       crt[626] = 32 | 0x0f00;
       crt[627] = 32 | 0x0f00;


       crt[629] = 89 | 0x0f00; 
       crt[630] = 101 | 0x0f00;
       crt[631] = 108 | 0x0f00;
       crt[632] = 108 | 0x0f00;
       crt[633] = 111 | 0x0f00;
       crt[634] = 119 | 0x0f00;
       crt[635] = 32 | 0x0f00;
       crt[636] = 32 | 0x0f00;
       crt[637] = 32 | 0x0f00;
       crt[638] = 32 | 0x0f00;

       crt[698] = 87 | 0x0f00; // white
       crt[699] = 104 | 0x0f00;
       crt[700] = 105 | 0x0f00;
       crt[701] = 116 | 0x0f00;
       crt[702] = 101 | 0x0f00;
       crt[703] = 32 | 0x0f00;
       crt[704] = 32 | 0x0f00;
       crt[705] = 32 | 0x0f00;
       crt[706] = 32 | 0x0f00;
       crt[707] = 32 | 0x0f00;

       crt[709] = 87 | 0x0f00; 
       crt[710] = 104 | 0x0f00;
       crt[711] = 105 | 0x0f00;
       crt[712] = 116 | 0x0f00;
       crt[713] = 101 | 0x0f00;
       crt[714] = 32 | 0x0f00;
       crt[715] = 32 | 0x0f00;
       crt[716] = 32 | 0x0f00;
       crt[717] = 32 | 0x0f00;
       crt[718] = 32 | 0x0f00;
         int j;
          for(int i=0;i<16;i++)
           if(colors[i]==1)j=i;
            switch(j){
      case 0:
         black(138);
          break;
      case 1:
          blue(218);
         break;
      case 2:
         green(298);
         break;
      case 3:
         aqua(378);
         break;
      case 4:
         red(458);
         break;
      case 5:
         purple(538);
         break;
      case 6:
         yellow(618);
         break;
      case 7:
         white(698);
         break;
      case 8:
         black(149);
         break;
      case 9:
         blue(229);
         break;
      case 10:
         green(309);
         break;
      case 11:
         aqua(389);
         break;
      case 12:
         red(469);
         break;
      case 13:
         purple(549);
         break;
      case 14:
         yellow(629);
         break;
      case 15:
         white(709);
         break;
}


}
void black(int pos){
    int color = 0xf000;
     crt[pos++] = 66 | color; // black
     crt[pos++] = 108 | color;
     crt[pos++] = 97 | color;
     crt[pos++] = 99 | color;
     crt[pos++] = 107 | color;
     crt[pos++] = 32 | color; 
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
}
void blue(int pos){
    int color = 0xf000;
     crt[pos++] = 66 | color; 
     crt[pos++] = 108 | color;
     crt[pos++] = 117 | color;
     crt[pos++] = 101| color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color; 
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
}
void green(int pos){
    int color = 0xf000;
     crt[pos++] = 71 | color; 
     crt[pos++] = 114 | color;
     crt[pos++] = 101 | color;
     crt[pos++] = 101| color;
     crt[pos++] = 110 | color;
     crt[pos++] = 32 | color; 
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
}
void aqua(int pos){
    int color = 0xf000;
     crt[pos++] = 65 | color; 
     crt[pos++] = 113 | color;
     crt[pos++] = 117 | color;
     crt[pos++] = 97| color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color; 
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
}
void red(int pos){
    int color = 0xf000;
     crt[pos++] = 82 | color; 
     crt[pos++] = 101 | color;
     crt[pos++] = 100 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color; 
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
}
void purple(int pos){
    int color = 0xf000;
     crt[pos++] = 80 | color; 
     crt[pos++] = 117 | color;
     crt[pos++] = 114 | color;
     crt[pos++] = 112| color;
     crt[pos++] = 108 | color;
     crt[pos++] = 101 | color; 
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
}
void yellow(int pos){
    int color = 0xf000;
     crt[pos++] = 89 | color; 
     crt[pos++] = 101 | color;
     crt[pos++] = 108 | color;
     crt[pos++] = 108| color;
     crt[pos++] = 111 | color;
     crt[pos++] = 119 | color; 
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
}
void white(int pos){
    int color = 0xf000;
     crt[pos++] = 87 | color; 
     crt[pos++] = 104 | color;
     crt[pos++] = 105 | color;
     crt[pos++] = 116| color;
     crt[pos++] = 101 | color;
     crt[pos++] = 32 | color; 
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
     crt[pos++] = 32 | color;
}
void
consputc(int c)
{
	if(panicked){
		cli();
		for(;;)
			;
	}

	if(c == BACKSPACE){
		uartputc('\b'); uartputc(' '); uartputc('\b');
	} else
		uartputc(c);
	cgaputc(c);
}

#define INPUT_BUF 128
struct {
	char buf[INPUT_BUF];
	uint r;  // Read index
	uint w;  // Write index
	uint e;  // Edit index
} input;


        static int calt=0;
        static int oalt=0;
        static int lalt=0;

 int carrier=0;

  

void
consoleintr(int (*getc)(void))
{
	int c, doprocdump = 0;
        

	acquire(&cons.lock);
	while((c = getc()) >= 0){
		switch(c){
		case C('P'):  // Process listing.
			// procdump() locks cons.lock indirectly; invoke later
			doprocdump = 1;
                        if(!lalt){ calt=0; oalt=0;}
                        if(lalt){ calt=1; oalt=1;}
			break;
		case C('U'):  // Kill line.
			while(input.e != input.w &&
			      input.buf[(input.e-1) % INPUT_BUF] != '\n'){
				input.e--;
				consputc(BACKSPACE);
			}
                           if(!lalt){ calt=0; oalt=0;}
                           if(lalt){ calt=1; oalt=1;}
			break;
		case C('H'): case '\x7f':  // Backspace
			if(input.e != input.w){
				input.e--;
				consputc(BACKSPACE);
			}
                           if(!lalt){ calt=0; oalt=0;}
                           if(lalt){ calt=1; oalt=1;}
			break;
                case A('C'):
                        if(!calt && !oalt && !lalt)calt=1;
                        else if(calt && oalt && lalt)calt=0;
                        else if(!calt && !oalt && lalt){calt=1; oalt=1;} 
                      break;
                case A('O'):
                      if(calt && !oalt && !lalt)oalt=1;
                      else if(calt && oalt && !lalt){ calt=0; oalt=0;}
                      else if(!calt && oalt && lalt)oalt=0;
                      else if(!calt && !oalt && lalt){ calt=1; oalt=1;}
                        break;
                case A('L'):  
                     if(calt && oalt && !lalt){
                        lalt=1;
                        for( int i=0; i<2000; i++){
                              help[i]=crt[i];
                         }
                         colors[0]=1;
                          for(int i=1;i<16;i++){
                            colors[i]=0;
                            }
                              meni();
                             }else if(!calt && !oalt && lalt){
                                   lalt=0; 
                                   for( int i=0; i<2000; i++){
                              crt[i]=(help[i]&0xff) ^ (fg^bg);
                              }
                              
                              }else if(calt && !oalt && !lalt){
                                     calt=0;
                                     }else if(!calt && oalt && lalt){calt=1;}
                                   
                        break;
		default:
                      /*  if(calt) crt[1500]= 49 | 0x0700;
                        else crt[1500]= 48 | 0x0700;
                        if(oalt) crt[1501]= 49 | 0x0700;
                        else crt[1501]= 48 | 0x0700;
                        if(lalt) crt[1502]= 49 | 0x0700;
                        else crt[1502]= 48 | 0x0700;*/
                      if(lalt){
                         int j;
                            if(c!=normalmap[0xC8] && c!=shiftmap[0xC8]  && c!=ctlmap[0xC8] && c!=altmap[0xC8] && c!=shiftcode[0xC8] && c!=togglecode[0xC8]){
                         calt=1;
                         oalt=1;
                         lalt=1;
                                 }
                            switch(c){
                             case 119: //w
                              for(int i=0;i<16; i++){
                                if(colors[i]==1)carrier=i;}
                               colors[carrier]=0;
                               carrier--;
                               if(carrier == -1 || carrier == 7)carrier+=8;
                               colors[carrier]=1;
                               meni();
                                break;
                             case 115:  //s
                              for(int i=0;i<16; i++){
                                if(colors[i]==1)carrier=i;}
                               colors[carrier]=0;
                               carrier++;
                               if(carrier == 8 || carrier == 16)carrier-=8;
                               colors[carrier]=1;
                               meni();
                                break;
                             case 97:  //a
                              for(int i=0;i<16; i++){
                                if(colors[i]==1)carrier=i;}
                               colors[carrier]=0;
                               if(carrier>=8)
                               carrier-=8;
                               else carrier +=8;
                               //carrier%=16;
                               //carrier= (carrier+8)%16;
                               colors[carrier]=1;
                                meni();
                                break;
                             case 100:  //d
                              for(int i=0;i<16; i++){
                                if(colors[i]==1)carrier=i;}
                               colors[carrier]=0;
                               if(carrier>=8)
                               carrier-=8;
                               else carrier +=8;
                               colors[carrier]=1;
                                 meni();
                                break;
                             case 101:  //e
                            
                              for(int i=0;i<16; i++)
                               if(colors[i]==1)j=i;
                              
                             switch(j){
                                   case 0:
                                   changefg(0x0000);
                                       break;
                                   case 1:
                                     changefg(0x0100);
                                      break;
                                   case 2:
                                    changefg(0x0200);
                                      break;
                                   case 3:
                                    changefg(0x0300);
                              break;
                                   case 4:
                                     changefg(0x0400);
                              break;
                                   case 5:
                                     changefg(0x0500);
                             
                               break;
                                   case 6:
                                    changefg(0x0600);
                             
                             break;
                                   case 7:
                                   changefg(0x0700);
                             break;
                                   case 8:
                                      changebg(0x0000);
                                      break;
                                   case 9:
                                      changebg(0x1000);
                                      break;
                                   case 10:
                                      changebg(0x2000);
                                      break;
                                   case 11:                             
                                      changebg(0x3000);
                                      break;
                                   case 12:
                                      changebg(0x4000);
                                      break;
                                   case 13:
                                      changebg(0x5000);
                                      break;
                                   case 14:                             
                                      changebg(0x6000);
                                      break;
                                   case 15:
                                      changebg(0x7000);
                                      break;
}
                              break;
                             case 114:   //r
                                  for(int i=0;i<16; i++)
                               if(colors[i]==1)j=i;
                             switch(j){
                                   case 0:
                                      changefg(0x0800);
                                       break;
                                   case 1:
                                       changefg(0x0900);
                                      break;
                                   case 2:
                                      changefg(0x0a00);
                                      break;
                                   case 3:
                                      changefg(0x0b00);
                                      break;
                                   case 4:
                                      changefg(0x0c00);
                                      break;
                                   case 5:
                                      changefg(0x0d00);
                                      break;
                                   case 6:
                                      changefg(0x0e00);
                                      break;
                                   case 7:                             
                                      changefg(0x0f00);
                                      break;
                                   case 8:
                                      changebg(0x0800);
                                      break;
                                   case 9:
                                      changebg(0x9000);
                                      break;
                                   case 10:
                                      changebg(0xa000);
                                      break;
                                   case 11:
                                      changebg(0xb000);
                                      break;
                                   case 12:
                                      changebg(0xc000);
                                      break;
                                   case 13:
                                      changebg(0xd000);
                                      break;                             
                                   case 14:
                                      changebg(0xe000);
                                      break;
                                   case 15:
                                      changebg(0xf000);
                                      break;
                             }
                              break;
                  }   
                             if(j==15){white(709); 
                             colors[15]=1;}
                                   }else{
                         if(c!=normalmap[0xC8] && c!=shiftmap[0xC8]  && c!=ctlmap[0xC8] && c!=altmap[0xC8] && c!=shiftcode[0xC8] && c!=togglecode[0xC8]){
                         calt=0;
                         oalt=0;
                         lalt=0;}
			if(c != 0 && input.e-input.r < INPUT_BUF){
				c = (c == '\r') ? '\n' : c;
				input.buf[input.e++ % INPUT_BUF] = c;
				consputc(c);
				if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
					input.w = input.e;
					wakeup(&input.r);
				}
			}
                        }
                                                       


			break;
		}
	}
	release(&cons.lock);
	if(doprocdump) {
		procdump();  // now call procdump() wo. cons.lock held
	}
}
void changefg(short c){
       fg=c;
         for(int i=0;i<2000;i++){
       if((bg==0x7000 || bg==0xf000)&& (fg==0x7000 || fg==0x7000) ) crt[i]=(help[i]&0xff) | (bg|fg);
          else   crt[i]=(help[i]&0xff) | (bg^fg);
       }
       meni();
}
void changebg(short c){
       bg=c;
         for(int i=0;i<2000;i++){
             crt[i]=(help[i]&0xff) | (bg^fg);
}
       meni();
}
int
consoleread(struct inode *ip, char *dst, int n)
{
	uint target;
	int c;

	iunlock(ip);
	target = n;
	acquire(&cons.lock);
	while(n > 0){
		while(input.r == input.w){
			if(myproc()->killed){
				release(&cons.lock);
				ilock(ip);
				return -1;
			}
			sleep(&input.r, &cons.lock);
		}
		c = input.buf[input.r++ % INPUT_BUF];
		if(c == C('D')){  // EOF
			if(n < target){
				// Save ^D for next time, to make sure
				// caller gets a 0-byte result.
				input.r--;
			}
			break;
		}
		*dst++ = c;
		--n;
		if(c == '\n')
			break;
	}
	release(&cons.lock);
	ilock(ip);

	return target - n;
}

int
consolewrite(struct inode *ip, char *buf, int n)
{
	int i;

	iunlock(ip);
	acquire(&cons.lock);
	for(i = 0; i < n; i++)
		consputc(buf[i] & 0xff);
	release(&cons.lock);
	ilock(ip);

	return n;
}

void
consoleinit(void)
{
	initlock(&cons.lock, "console");

	devsw[CONSOLE].write = consolewrite;
	devsw[CONSOLE].read = consoleread;
	cons.locking = 1;

	ioapicenable(IRQ_KBD, 0);
}

